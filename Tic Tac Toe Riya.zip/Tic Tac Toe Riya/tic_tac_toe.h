/* Created by Riya Patel on 7/8/20. */

#ifndef TIC_TAC_TOE_RIYA_TIC_TAC_TOE_H
#define TIC_TAC_TOE_RIYA_TIC_TAC_TOE_H

#endif //TIC_TAC_TOE_RIYA_TIC_TAC_TOE_H


/* my functions */
void printDirections();
void board();
void placeTurn(int choice1, int choice2, char mark);
char checkWin();
void funcRestart();
